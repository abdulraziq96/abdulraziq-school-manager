AMSC Hostel Attendance (mobile)

Open index.html in Chrome. It is a single file: no other file is needed.
If you open it from inside the zip without extracting, it still works.

Downloading Excel: tap "Download Excel", then tap "Download" in the
"File ready" box. If that does not save, tap "Share / Save" and pick Files or Drive.

Download a backup from the Data tab regularly.
